package com.pancorp.strategy;

/**
 * This interface for a strategy type designed for trending market
 * 
 * @author
 */
public interface ITrendFollowing extends IStrategy {

}
