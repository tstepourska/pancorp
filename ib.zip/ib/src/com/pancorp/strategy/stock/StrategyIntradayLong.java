package com.pancorp.strategy.stock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StrategyIntradayLong {
	private static Logger log = LogManager.getLogger(StrategyIntradayLong.class);
	
	//entry conditions:
	//high volume
	//large day range
	
	//targets:
	//profit $100 per contract per week
	//stop loss is $66 per contract (2/3 of profit)
	
	//exit conditions:
	//profit target reached (less losses, commissions and other fees)
	//OR
	//stop loss reached
	
	//timeframes
	// ?optional? - daily charts to determine the global trend - optional?
	// 1-minute timeframe to enter the trade
	// 5-minute timeframe to exit the trade
	// 15-minute timeframe to help determine the trend throughout the duration of the trade
	
	public void execute(){
		
	}
	
	public void query() throws Exception{
		
	}
	
	public void enter()  throws Exception{
		
	}

	public void exit(){
		
	}
}
