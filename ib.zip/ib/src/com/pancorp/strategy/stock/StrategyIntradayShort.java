package com.pancorp.strategy.stock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StrategyIntradayShort {
	private static Logger log = LogManager.getLogger(StrategyIntradayShort.class);
	
	public void execute(){
		
	}
	
	public void query() throws Exception{
		
	}
	
	public void enter()  throws Exception{
		
	}

	public void exit(){
		
	}
}
