package com.pancorp.strategy;

import java.util.HashMap;

import com.pancorp.condition.ICondition;

public interface IStrategy {
	public void execute();
	public void query() throws Exception;
	public void enter()  throws Exception;
	public void createOrder() throws Exception;
	public void submitOrder() throws Exception;
	public void exit();
	
	public HashMap getOpenedOrders();
	public HashMap<String, ICondition> getEntryConditions();	
	public void setEntryConditions(HashMap<String, ICondition> m);	
	public HashMap<String, ICondition> getExitConditions();
	public void setExitConditions(HashMap<String, ICondition> m);

}
