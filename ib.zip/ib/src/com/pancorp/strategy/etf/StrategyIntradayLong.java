package com.pancorp.strategy.etf;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.pancorp.strategy.ITrendFollowing;
import com.pancorp.strategy.StrategyAbstract;

public class StrategyIntradayLong extends StrategyAbstract implements ITrendFollowing {
	private static Logger log = LogManager.getLogger(StrategyIntradayLong.class);
	
	private double stopLossAmt;  //0.03
	private double profitTargetAmt;	//0.03/2*3
	
	public StrategyIntradayLong(){

	}
	
	@Override
	public void execute(){
		
	}
	
	@Override
	public void query() throws Exception{
		
	}
	
	@Override
	public void enter()  throws Exception{
		
	}

	@Override
	public void exit(){
		
	}
}
