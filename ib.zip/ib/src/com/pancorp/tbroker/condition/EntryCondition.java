package com.pancorp.tbroker.condition;

public class EntryCondition extends AbstractCondition {

}
