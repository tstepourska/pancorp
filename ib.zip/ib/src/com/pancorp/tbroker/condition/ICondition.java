package com.pancorp.tbroker.condition;

public interface ICondition {
	public void setMet(boolean b);
	public boolean isMet();
}
