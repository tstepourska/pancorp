package com.pancorp.tbroker.instrument;

public enum InstrumentTypes {

	STOCK, FUTURE, FOREX;

	public static String getValue(InstrumentTypes t){
		String value;
		switch(t){
		case STOCK:
			value = "STOCK";
		break;
		case FUTURE:
			value = "FUTURE";
			break;
		case FOREX:
			value = "FOREX";
			break;
			default:
			value =null;
		}
		
		return value;
	}
}
