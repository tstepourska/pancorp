package com.pancorp.tbroker.instrument;

public class Instrument {

	private String ticker;
	private String type;

	public void setTicker(String s){
		this.ticker = s;
	}
	
	public void setType(String t){
		this.type = t;
	}
}
