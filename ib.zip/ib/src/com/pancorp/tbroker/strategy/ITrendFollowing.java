package com.pancorp.tbroker.strategy;

/**
 * This interface for a strategy type designed for trending market
 * 
 * @author
 */
public interface ITrendFollowing extends IStrategy {

}
