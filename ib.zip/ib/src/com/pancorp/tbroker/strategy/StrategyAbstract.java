package com.pancorp.tbroker.strategy;

import java.util.HashMap;
import java.util.LinkedList;

import com.pancorp.tbroker.condition.ICondition;
import com.pancorp.tbroker.instrument.Instrument;

public abstract class StrategyAbstract extends Thread implements IStrategy {
	
	
	/**
	 * Strategies very according
	 * market conditions
	 * time of the day
	 * timeframe for trading
	 * 
	 * 3 categories
	 * 		breakout
	 * 		retracement
	 * 		reversal
	 * 
	 * Example:
	 * primary strategy is designed for non-trending market. It is a 
	 * breakout strategy which aims to jump on bandwagon upon the 
	 * continuation of a strong trend
	 */
	
	/**
	 * Setup is the set of characteristics that enable you to identify 
	 * a high probability trade prior to your entry trigger being hit.
	 * 
	 * Example:
	 * 1. Opening gap id 1%-3%
	 * 2. The 50-day moving average must be clearly in the direction 
	 * of the proposed trade
	 * 3. The gap should be into resistance/support, but not breaching it
	 * 4. Evidence of strong volume pre-market
	 * 
	 * Example for secondary strategy:
	 * 1. Price must be in a clear up/dodwn trend, according to my definition 
	 * of a trend, which is XYZ
	 * 2. Price breaks  throuhg yesterday's high / low of the dayto make new high / low
	 * 3. Price pulls back to yesterday's high / lowbut does not break it.
	 */
	
	/**
	 * Signals to trigger my entry
	 * 
	 * Example: Primary strategy:
	 * 
	 * To go long upon breach of the open on a 5 minute chart providing the open 
	 * is high of the day (H.O.D). Reverse for a short trade
	 * 
	 * Example Secondary strategy
	 * 
	 * To go long when the stock resumes the direction of the trend and hits 
	 * yesterday high on a 10 minute chart. Reverse for a short trade
	 * 
	 *
	 */
	
	/**
	 * TODO  Specify what you need to do to CLOSE your position:
	 * If you are long, you have to SELL to close
	 * If you are short, you have to BUY to close
	 */
	
	/**
	 * Recording trades
	 * Entries, exits, stops, targets, S&R levels, open/close, high/low, 
	 * duration of trades, key lessons learned
	 */
	///////////////////////////////////////////////////////////////
	//		CONSTANTS
	///////////////////////////////////////////////////////////////
	/**
	 * Percent of total account amount, that I can afford to lose, 
	 * shared between all trades; ex $10000 * 0.05 = $500
	 * Total trailing stops amount for all concurrent positions 
	 * must not exceed this number: new position can't be opened
	 */
	public static final double TOTAL_STOP_LOSS_PERCENT = 0.05;
	
	/**
	 * Percent of original amount spent on a single position that can be lost
	 *  0.03-0.07
	 * TODO   is is the same for long and short positions?
	 */
	public static final double TRAILING_STOP_PERCENT   = 0.03;
	
	/**
	 * PErcent of  total account amount that can be invested 
	 * into one economic sector, shared between all positions,
	 * ex $10000 * 0.03 = $300
	 * 
	 * TODO to confirm if this is applicable to day trading
	 */
	public static final double TOTAL_SECTOR_EXPOSURE_PERCENT = 0.03;
	
	/**
	 * Percent of the total account amount that allowed to be spent  
	 * on a single trade.
	 * Usually between 1 (for most accounts) and 3 (very small accounts) %
	 */
	public static final double LOSS_PER_TRADE				= 0.03;
	
	/**
	 * Percent of the total account amount that allowed to be lost 
	 * per day
	 */
	public static final double LOSS_PER_DAY					= 0.03;
	
	/**
	 * Largest % drawdown on each strategy employed, multiplied 
	 * by this factor (may be within the range between 1.5 to 2.0)
	 * If reached, STOP trading this strategy immediately (close and disable)
	 */
	public static final double STRATEGY_DRAWDOWN_FACTOR = 1.6;
	
	/**
	 * Optional for losing trades. Allows exit before hitting trailing stop.
	 * If the price does not move this 
	 * number of points in my favour, position must be closed
	 */
	//public static final double FAVOUR_POINTS	 = 0.3;  //TODO to determine
	
	/**
	 * Winning trade: Optional, for advanced strategy. Beginners can exit right after their 
	 * profit target is made. 
	 * Winning trades exit rule(s) / condition(s)
	 * Close position immediately, if the price hits crossing XYZ moving 
	 * average, or other rule
	 */
	
	/**
	 * Winning  trade: closing half of the position at the first target, or at the first sign
	 * of weakness, and let the otoher half run
	 * For ex, upon increase/decrease in volume compared to the previous price bar
	 */
	
	/**
	 * Winning  trade: closing the other half of the position at the 
	 * --very end of the day
	 * --within the X% of the high of the day (H.O.D)
	 * For ex, upon increase/decrease in volume compared to the previous price bar
	 */
	
	public static final String endOfDay = "16:45:00";
	
	////////////////////////////////////////////////////////////////////////
	// 			END OF CONSTANTS
	////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////
	//		STRATEGIES GLOBAL VARIABLES
	///////////////////////////////////////////////////////////////////////

	
	/**
	 * Success ratio: probability of the trade being successful. 
	 * Number of profitable trades divided by a number of total trades 
	 * multiplied by 100
	 * 
	 * Has to be established, monitored and updated, depending on 
	 * the trade setup (TODO - to define and test it) and numerous 
	 * external variables
	 * For example, the setup may have a higher probability of success 
	 * if it appears just above the round number (for a long position) 
	 * than it does if it appears just beneath it
	 */
	public static double PROBABILITY_OF_SUCCESS = 50;  //TODO - to determine and test!!
	
	/**
	 * To calculate, need to know Sharpe and Success ratios
	 * 
	 * Example:
	 * 		Success ratio: 2:1 (66%)
	 * 		Sharpe ratio: 1.5:1 so if we risk $40, we stand to make $60 on the winning trades
	 * 
	 * The success ratio tells us that we win 2 out of every 3 trades, and the Sharpe ratio 
	 * tells us, that, of the 2 winners, we make 2 * +$60+ = +$120
	 * Our one losing trade of the three costs us -$40
	 * On all three trades we risked $40 and ended up with a net gain of +$80
	 * 
	 * Therefore, if we divide the net gain by the amount we risked, we arrive at 
	 * risk-reward ratio of 2:1
	 * 
	 * Caution: assumed that we only trade the setups defined in our plan and that 
	 * they have been thoroughly back and forward tested to determine their probability 
	 * of success (Success Ratio)
	 */
	public static double RISK_REWARD_RATIO      = 50;
	
	/**
	 * Average number of $$$ made on profitable trades relative to the average 
	 * number of $$$ lost on unprofitable trades: divide avg $$$ gained in profitable 
	 * trades on combined figure of the average number of $$$ gained and lost, 
	 * multiplied by 100
	 */
	public static double SHARPE_RATIO      		= 50;	//TODO to determine and test
	////////////////////////////////////////////////////////////////////////////////////
	//		END OF STRATEGIES GLOBAL VARIABLES
	////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////////
	// 		COMMON MEMBERS
	///////////////////////////////////////////////////////////////////////////////////
	/**
	 * On/off switch
	 */
	public boolean working = true;
	
	protected HashMap openedOrders;
	protected HashMap<String, ICondition> entryConditions;
	protected HashMap<String, ICondition> exitConditions;	
	protected double tradeAmount;
	
	/**
	 * Position
	 */
	public boolean open = false;
	
	private Instrument instrument;
	

	//////////////////////////////////////////////////////////////////////////////////
	//		END OF COMMON MEMBERS
	//////////////////////////////////////////////////////////////////////////////////

	/**
	 * @return the instrument
	 */
	public Instrument getInstrument() {
		return instrument;
	}

	/**
	 * @param instrument the instrument to set
	 */
	public void setInstrument(Instrument instrument) {
		this.instrument = instrument;
	}

	//////////////////////////////////////////////////////////////////////////////////
	//		PUBLIC METHODS
	//////////////////////////////////////////////////////////////////////////////////
	/**
	 * @return the tradeAmount
	 */
	public double getTradeAmount() {
		return tradeAmount;
	}

	/**
	 * @param tradeAmount the tradeAmount to set
	 */
	public void setTradeAmount(double tradeAmount) {
		this.tradeAmount = tradeAmount;
	}
	
	@Override
	public HashMap getOpenedOrders(){
		return this.openedOrders;
	}
	
	@Override
	public HashMap<String, ICondition> getEntryConditions(){
		return this.entryConditions;
	}
	
	@Override
	public void setEntryConditions(HashMap<String, ICondition> m){
		this.entryConditions = m;
	}
	
	@Override
	public HashMap<String, ICondition> getExitConditions(){
		return this.exitConditions;
	}
	
	@Override
	public void setExitConditions(HashMap<String, ICondition> m){
		this.exitConditions = m;
	}	
	
	public void update(String location) {
		
	}
	
	public void init(String location){
		
	}
	
	@Override
	public void createOrder() throws Exception{
		
	}
	
	@Override
	public void submitOrder() throws Exception{
		
	}
	/////////////////////////////////////////////////////////////////
	//		END OF PUBLIC METHODS
	/////////////////////////////////////////////////////////////////
	
	//////////////////////////////////////////////////
	//		ABSTRACT METHODS
	//////////////////////////////////////////////////
	//@Override
	//public abstract boolean query() throws Exception;
	@Override
	public abstract void enter()  throws Exception;
	@Override
	public abstract void exit() throws Exception;
	//////////////////////////////////////////////////
	//		END OF ABSTRACT METHODS
	//////////////////////////////////////////////////
}
