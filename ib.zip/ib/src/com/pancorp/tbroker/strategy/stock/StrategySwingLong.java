package com.pancorp.tbroker.strategy.stock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class StrategySwingLong {
	private static Logger log = LogManager.getLogger(StrategySwingLong.class);
	
	public void execute(){
		
	}
	
	public void query() throws Exception{
		
	}
	
	public void enter()  throws Exception{
		
	}

	public void exit(){
		
	}
}
