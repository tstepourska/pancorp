package com.pancorp.tbroker.strategy.stock;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.pancorp.tbroker.strategy.StrategyAbstract;
import com.pancorp.tbroker.util.Utils;

public class StrategyIntradayLong extends StrategyAbstract {
	private static Logger lg = LogManager.getLogger(StrategyIntradayLong.class);
		
	public StrategyIntradayLong(){
		this.setName("Vlad");
	}
	
	@Override
	public void run(){
		//started after indicator was found
		
		//check account amt
		
		
		try {
			//create limit BUY order with the price .... to adjust by percentage
			createOrder();
			
			//create stop loss SELL order		
			//create target profile SELL order
			//==================================
			//create OCO order with 2 orders above
			createOrder();
			
			//submit limit BUY order
			submitOrder();
		} catch (Exception e2) {
			Utils.logError(lg, e2);
			working = false;
		}
		
		boolean enter = false;
		// 1-minute timeframe to enter the trade
		while(working){
		try {
			enter = queryEnter();
			if(enter)
				break;

			Thread.sleep(60000);
			continue;
			
		} catch (Exception e1) {
			Utils.logError(lg, e1);
			working = false;
		}
		}
		
		try {
			enter();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	
		//check when filled
		open = true;

		boolean exit = false;
		//monitor: receive 1-minute bars and look for exit condition(s)
		while(working){
			try {
				exit = queryExit();
				if(exit){
					break;
				}

				Thread.sleep(60000);
				continue;

			}
			catch(Exception e){
				Utils.logError(lg, e);
			}
		}
		
		//submit OCO order and close position
		try {
			exit();
			
			//check when filled
			open = false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	//entry conditions:

	
	//targets:
	//profit $100 per contract per week
	//stop loss is $66 per contract (2/3 of profit)
	
	//exit conditions:
	//profit target reached (less losses, commissions and other fees)
	//OR
	//stop loss reached
	
	//timeframes
	/// 60-min, 30-min, 15-min, 10-min, 5-min, 3-min, 1-min
	// ?optional? - daily charts to determine the global trend - optional?
	// 1-minute timeframe to enter the trade
	// 5-minute timeframe to exit the trade
	// 15-minute timeframe to help determine the trend throughout the duration of the trade
	
	/**
	 * 
	 */
	public boolean queryEnter() throws Exception{
		boolean enter = false;
		// 1-minute timeframe to check for exit conditions
		
		return enter;
	}
	
	/**
	 * 
	 */
	public boolean queryExit() throws Exception{
		boolean exit = false;
		// 1-minute timeframe to check for exit conditions
		
		return exit;
	}
	
	@Override
	public void enter()  throws Exception{
		// 1-minute timeframe to enter the trade
		
	}

	@Override
	public void exit() throws Exception {
		// 1-minute timeframe to exit the trade
		submitOrder();
	}
}
