package com.pancorp.tbroker.data;

import com.pancorp.tbroker.instrument.Instrument;
import com.pancorp.tbroker.instrument.InstrumentTypes;

public class DataAnalyzer {

	public Instrument invoke(){
		Instrument in = new Instrument();
		
		//get all data 
		
		// 15-minute timeframe to help determine the trend throughout the duration of the trade
		
		//select market and instrument: future, forex or stocks, trending
		
		
		in.setTicker("IBM");
		in.setType(InstrumentTypes.getValue( InstrumentTypes.STOCK));
		
		//keep getting data for selected security in 10-mins bars and scan it for indicators
		
		//once found, return
		
		return in;
	}

}
