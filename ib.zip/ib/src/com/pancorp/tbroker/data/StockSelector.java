package com.pancorp.tbroker.data;

public class StockSelector {

	//high volume  <2,000,000 per day
	//large day range <

}
