package com.pancorp.tbroker;

import com.pancorp.tbroker.data.DataAnalyzer;
import com.pancorp.tbroker.instrument.Instrument;
import com.pancorp.tbroker.strategy.IStrategy;
import com.pancorp.tbroker.strategy.StrategyAbstract;
import com.pancorp.tbroker.strategy.StrategySelector;

/**
 * @author 
 *
 */
public class TBrokerMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//check the account amount and margin
		
		//start DataAnalizer
		DataAnalyzer da = new DataAnalyzer();
		Instrument in = da.invoke();
		
		//when found, select and start strategy
		//do not receive data bulk until started strategy expires
		StrategySelector ss = new StrategySelector();
		StrategyAbstract strategy = ss.resolveStrategy(in);
		strategy.setInstrument(in);
		
		try {
			strategy.join();
			strategy.start();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		//as of now, only one strategy is allowed to run at a time
		
		//strategy exits, or force closing, if end of day
		
		
		//record trade stats

	}

}
