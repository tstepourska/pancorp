package com.pancorp.condition;

public interface ICondition {
	public void setMet(boolean b);
	public boolean isMet();
}
