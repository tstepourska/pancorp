package com.pancorp.condition;

public class EntryCondition extends AbstractCondition {

}
